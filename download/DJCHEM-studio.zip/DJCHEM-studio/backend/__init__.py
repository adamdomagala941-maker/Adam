"""DJCHEM label application backend."""
